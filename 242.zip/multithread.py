'''
Created Date: Thursday, January 30th 2020, 11:17:28 am
Author: Longze SU
'''

import crawler
import time
from multiprocessing import Pool, Queue
from threading import Thread, Lock
import csv
import os
 

# def MultiProcessing(queue, processor, task): 
#     if queue.qsize() < processor: 
#         return

#     p = Pool(task)
#     for i in range(processor):
#         p.apply_async(crawler.crawler,args=(queue.get(),))
#     p.close    
#     p.join
def MultiThread(queue, thread): 
    for i in range(thread):
        t = Thread(target=crawler.crawler, args=(queue.get(),))
        t.start()
    t.join() 

def getQuery(dir,file): 
    res = []
    with open(os.path.join(dir,file), 'r') as f:
        reader = csv.reader(f) 
        for line in reader: 
            res.append(line[0])
    return res

def main(): 
    dir_name = 'file'
    file_name = 'query1.csv'
    thread_num = 5
    queries = getQuery(dir_name, file_name)
    q = Queue()
    for i in queries: 
        q.put(i)
    size = len(queries)
    MT = []
    # MP = []
    while q.qsize(): 
        if q.qsize() < thread_num:
            start_time = time.time() 
            MultiThread(q, q.qsize()) 
            end_time = time.time()

            total_time = end_time - start_time
            MT.append(total_time)
            break

        start_time = time.time()    
        MultiThread(q, thread_num)
        end_time = time.time()

        total_time = end_time - start_time
        MT.append(total_time)


    print("MultiThread "+str(thread_num)+" End, Task is: "+ str(size) + " , Time is：{}".format(sum(MT)))


if __name__ == "__main__":
    main()